import SwiftUI
import PlaygroundSupport

// MARK: - Models
struct Resource {
    var energy: Double
    var water: Double
    var happiness: Double
    var pollution: Double
    var wood: Double
    var steel: Double
    var credits: Double
}

enum BuildingType: String, CaseIterable, Identifiable {
    case solarPanel = "Solar Panel"
    case windTurbine = "Wind Turbine"
    case house = "House"
    case park = "Park"
    case waterTreatment = "Water Treatment"
    
    var id: String { rawValue }
    
    var impact: Resource {
        switch self {
        case .solarPanel:
            return Resource(energy: 10, water: 0, happiness: 0, pollution: -5, wood: 0, steel: -10, credits: -20)
        case .windTurbine:
            return Resource(energy: 15, water: 0, happiness: -2, pollution: -3, wood: 0, steel: -15, credits: -30)
        case .house:
            return Resource(energy: -5, water: -5, happiness: 5, pollution: 3, wood: -10, steel: -5, credits: -15)
        case .park:
            return Resource(energy: 0, water: -2, happiness: 10, pollution: -8, wood: -5, steel: 0, credits: -10)
        case .waterTreatment:
            return Resource(energy: -3, water: 15, happiness: 2, pollution: -4, wood: -5, steel: -10, credits: -25)
        }
    }
    
    var icon: String {
        switch self {
        case .solarPanel: return "sun.max"
        case .windTurbine: return "wind"
        case .house: return "house"
        case .park: return "leaf"
        case .waterTreatment: return "drop"
        }
    }
}

struct Building: Identifiable, Equatable {
    let id = UUID()
    let type: BuildingType
    let position: CGPoint
    var level: Int = 1
    var creationTime: Date = Date()
    
    static func == (lhs: Building, rhs: Building) -> Bool {
        lhs.id == rhs.id
    }
    
    var scaledImpact: Resource {
        let base = type.impact
        return Resource(
            energy: base.energy * Double(level),
            water: base.water * Double(level),
            happiness: base.happiness * Double(level),
            pollution: base.pollution * Double(level),
            wood: base.wood,
            steel: base.steel,
            credits: base.credits
        )
    }
}

// MARK: - Game State
class GameState: ObservableObject {
    @Published var resources = Resource(energy: 300, water: 300, happiness: 50, pollution: 0, wood: 500, steel: 500, credits: 1000)
    @Published var buildings: [Building] = []
    @Published var selectedBuilding: BuildingType?
    @Published var tips: [String] = []
    @Published var citizenFeedback: [String] = []
    @Published var challenges: [Challenge] = [
        Challenge(description: "Reduce pollution to 20", target: .pollution(20), reward: Resource(energy: 10, water: 0, happiness: 0, pollution: 0, wood: 10, steel: 10, credits: 50), timeLimit: 120)
    ]
    @Published var cityName: String = "My Eco City"
    @Published var weather: String = "Sunny"
    @Published var isRemoveMode: Bool = false
    @Published var population: Int = 0
    @Published var ecoScore: Double = 50
    @Published var carbonEmissions: Double = 0
    @Published var aqi: Int = 0
    
    init() {
        startResourceRegeneration()
        startWeatherCycle()
        startBuildingUpgrades()
    }
    
    func addBuilding(_ building: Building) {
        let cost = building.type.impact
        if resources.wood + cost.wood >= 0 && resources.steel + cost.steel >= 0 && resources.credits + cost.credits >= 0 {
            buildings.append(building)
            updateResources(with: cost)
            if building.type == .house { population += 10 * building.level }
            checkResourceLevels()
            addCitizenFeedback()
            checkChallenges()
            updateEcoScore()
            updateEnvironmentalMetrics()
        } else {
            tips.append("Not enough resources or credits to build \(building.type.rawValue)!")
        }
    }
    
    func removeBuilding(at position: CGPoint) {
        if let index = buildings.firstIndex(where: { $0.position == position }) {
            let building = buildings[index]
            let reversedImpact = Resource(
                energy: -building.scaledImpact.energy,
                water: -building.scaledImpact.water,
                happiness: -building.scaledImpact.happiness,
                pollution: -building.scaledImpact.pollution,
                wood: -building.type.impact.wood,
                steel: -building.type.impact.steel,
                credits: -building.type.impact.credits
            )
            buildings.remove(at: index)
            if building.type == .house { population -= 10 * building.level }
            updateResources(with: reversedImpact)
            tips.append("Removed \(building.type.rawValue).")
            checkResourceLevels()
            checkChallenges()
            updateEcoScore()
            updateEnvironmentalMetrics()
        }
    }
    
    func autoBuildCity() {
        buildings.removeAll()
        population = 0
        resources = Resource(energy: 300, water: 300, happiness: 50, pollution: 0, wood: 500, steel: 500, credits: 1000)
        tips.removeAll()
        
        // 12x16 grid: Design zones
        for x in stride(from: 0, through: 550, by: 50) {
            for y in stride(from: 0, through: 750, by: 50) {
                let position = CGPoint(x: x, y: y)
                let type: BuildingType
                
                // Top-left: Residential (houses)
                if x <= 250 && y <= 350 {
                    type = .house
                }
                // Top-right: Energy (solar/wind alternating)
                else if x > 250 && y <= 350 {
                    type = (x + y) % 100 == 0 ? .solarPanel : .windTurbine
                }
                // Bottom-left: Green spaces (parks)
                else if x <= 250 && y > 350 {
                    type = .park
                }
                // Bottom-right: Utilities and some parks
                else {
                    type = (x + y) % 150 == 0 ? .waterTreatment : .park
                }
                
                let building = Building(type: type, position: position)
                addBuilding(building)
            }
        }
        
        tips.append("Auto-Built City: Houses in top-left for population, solar/wind in top-right for energy, parks in bottom-left for happiness/pollution, water treatment in bottom-right for supply.")
    }
    
    private func updateResources(with impact: Resource) {
        resources.energy = max(0, min(1000, resources.energy + impact.energy))
        resources.water = max(0, min(1000, resources.water + impact.water))
        resources.happiness = max(0, min(100, resources.happiness + impact.happiness))
        resources.pollution = max(0, min(1000, resources.pollution + impact.pollution))
        resources.wood = max(0, resources.wood + impact.wood)
        resources.steel = max(0, resources.steel + impact.steel)
        resources.credits = max(0, resources.credits + impact.credits)
    }
    
    private func checkResourceLevels() {
        tips.removeAll()
        if resources.energy < 50 { tips.append("Low energy! Add solar or wind power.") }
        if resources.water < 50 { tips.append("Water shortage! Build water treatment.") }
        if resources.happiness < 30 { tips.append("Citizens need parks for happiness.") }
        if resources.pollution > 700 { tips.append("High pollution! Add green spaces.") }
    }
    
    private func addCitizenFeedback() {
        if resources.happiness < 30 {
            citizenFeedback.append("We need more parks!")
        } else if resources.pollution > 500 {
            citizenFeedback.append("The air’s getting bad!")
        } else {
            citizenFeedback.append("Great job, Mayor!")
        }
        if citizenFeedback.count > 3 { citizenFeedback.removeFirst() }
    }
    
    private func startResourceRegeneration() {
        Timer.scheduledTimer(withTimeInterval: 10.0, repeats: true) { _ in
            let populationImpact = Resource(
                energy: -0.1 * Double(self.population),
                water: -0.1 * Double(self.population),
                happiness: 0,
                pollution: 0.05 * Double(self.population),
                wood: 0,
                steel: 0,
                credits: 0.5 * Double(self.population)
            )
            self.updateResources(with: Resource(
                energy: (self.weather == "Sunny" ? 5 : 2) + populationImpact.energy,
                water: 2 + populationImpact.water,
                happiness: populationImpact.happiness,
                pollution: populationImpact.pollution,
                wood: 3,
                steel: 2,
                credits: populationImpact.credits
            ))
            self.updateEcoScore()
            self.updateEnvironmentalMetrics()
        }
    }
    
    private func startWeatherCycle() {
        Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { _ in
            self.weather = Bool.random() ? "Sunny" : "Stormy"
            if self.weather == "Stormy" {
                self.updateResources(with: Resource(energy: -5, water: 5, happiness: -2, pollution: 0, wood: 0, steel: 0, credits: 0))
                self.tips.append("Storm hits! Energy down, water up.")
            }
        }
    }
    
    private func startBuildingUpgrades() {
        Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { _ in
            for (index, building) in self.buildings.enumerated() {
                if building.level < 3 {
                    self.buildings[index].level += 1
                    self.updateResources(with: building.type.impact)
                    self.tips.append("\(building.type.rawValue) upgraded to level \(self.buildings[index].level)!")
                    if building.type == .house { self.population += 10 }
                    self.updateEcoScore()
                    self.updateEnvironmentalMetrics()
                }
            }
        }
    }
    
    func checkChallenges() {
        for (index, challenge) in challenges.enumerated() {
            if !challenge.isCompleted && challenge.target.isAchieved(resources: resources) {
                challenges[index].isCompleted = true
                updateResources(with: challenge.reward)
                tips.append("Challenge completed: \(challenge.description)!")
            }
        }
    }
    
    private func updateEcoScore() {
        ecoScore = max(0, min(100, (resources.happiness * 0.5) - (resources.pollution * 0.5 / 10) + (resources.energy * 0.2 / 10)))
    }
    
    private func updateEnvironmentalMetrics() {
        carbonEmissions = resources.pollution * 10 // Tons of CO2
        aqi = Int(min(500, resources.pollution * 5)) // AQI 0-500 scale
    }
}

struct Challenge: Identifiable {
    let id = UUID()
    let description: String
    let target: ChallengeTarget
    let reward: Resource
    let timeLimit: Double
    var isCompleted: Bool = false
    
    enum ChallengeTarget {
        case pollution(Double)
        
        func isAchieved(resources: Resource) -> Bool {
            switch self {
            case .pollution(let value):
                return resources.pollution <= value
            }
        }
    }
}

// MARK: - Views
struct ResourceBar: View {
    let title: String
    let value: Double
    let color: Color
    let icon: String
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon).foregroundColor(color)
            VStack(alignment: .leading, spacing: 4) {
                Text("\(title): \(Int(value))/\(title == "Credits" ? "∞" : "1000")")
                    .font(.system(size: 12, weight: .medium))
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        Rectangle().fill(Color.gray.opacity(0.2))
                        Rectangle()
                            .fill(LinearGradient(gradient: Gradient(colors: [color.opacity(0.7), color]), startPoint: .leading, endPoint: .trailing))
                            .frame(width: geometry.size.width * value / (title == "Credits" ? 1000 : 1000))
                            .animation(.easeInOut(duration: 0.5), value: value)
                    }
                }
                .frame(height: 10)
                .cornerRadius(5)
            }
        }
    }
}

struct BuildingSelector: View {
    @ObservedObject var gameState: GameState
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 20) {
                ForEach(BuildingType.allCases) { type in
                    VStack(spacing: 6) {
                        Image(systemName: type.icon)
                            .font(.system(size: 28))
                            .foregroundColor(gameState.selectedBuilding == type ? .blue : .gray)
                            .frame(width: 50, height: 50)
                            .background(Circle().fill(Color.white.opacity(0.8)))
                            .scaleEffect(gameState.selectedBuilding == type ? 1.1 : 1.0)
                            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: gameState.selectedBuilding)
                        Text(type.rawValue)
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .padding(8)
                    .background(Color.blue.opacity(gameState.selectedBuilding == type ? 0.2 : 0.05))
                    .cornerRadius(10)
                    .onTapGesture {
                        withAnimation {
                            gameState.selectedBuilding = type
                        }
                    }
                }
            }
            .padding()
        }
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct ContentView: View {
    @StateObject private var gameState = GameState()
    @State private var showTips = false
    
    var body: some View {
        VStack(spacing: 12) {
            // City Name and Weather
            HStack {
                TextField("City Name", text: $gameState.cityName)
                    .font(.system(size: 18, weight: .bold))
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Spacer()
                Text(gameState.weather)
                    .font(.system(size: 14))
                    .padding(6)
                    .background(gameState.weather == "Sunny" ? Color.yellow.opacity(0.3) : Color.gray.opacity(0.3))
                    .cornerRadius(8)
            }
            .padding(.horizontal)
            
            // Environmental Metrics
            HStack(spacing: 20) {
                Text("CO2: \(Int(gameState.carbonEmissions)) tons")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(gameState.carbonEmissions > 500 ? .red : .green)
                Text("AQI: \(gameState.aqi)")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(gameState.aqi > 100 ? .red : .green)
                Spacer()
                VStack(alignment: .trailing) {
                    Text("Pop: \(gameState.population)")
                        .font(.system(size: 14))
                    Text("Eco: \(Int(gameState.ecoScore))")
                        .font(.system(size: 14))
                        .foregroundColor(gameState.ecoScore > 75 ? .green : .orange)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(.systemGray5))
            .cornerRadius(8)
            
            // Resource Display
            VStack(spacing: 12) {
                ResourceBar(title: "Energy", value: gameState.resources.energy, color: .yellow, icon: "bolt.fill")
                ResourceBar(title: "Water", value: gameState.resources.water, color: .blue, icon: "drop.fill")
                ResourceBar(title: "Happiness", value: gameState.resources.happiness, color: .green, icon: "face.smiling")
                ResourceBar(title: "Pollution", value: gameState.resources.pollution, color: .red, icon: "smoke.fill")
                ResourceBar(title: "Wood", value: gameState.resources.wood, color: .brown, icon: "tree")
                ResourceBar(title: "Steel", value: gameState.resources.steel, color: .gray, icon: "wrench")
                ResourceBar(title: "Credits", value: gameState.resources.credits, color: .purple, icon: "dollarsign.circle")
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(radius: 4)
            
            // City Grid
            ZStack {
                Rectangle()
                    .fill(Color.green.opacity(0.1))
                    .overlay(
                        GeometryReader { geometry in
                            Path { path in
                                stride(from: 0, to: geometry.size.width, by: 50).forEach { x in
                                    path.move(to: CGPoint(x: x, y: 0))
                                    path.addLine(to: CGPoint(x: x, y: geometry.size.height))
                                }
                                stride(from: 0, to: geometry.size.height, by: 50).forEach { y in
                                    path.move(to: CGPoint(x: 0, y: y))
                                    path.addLine(to: CGPoint(x: geometry.size.width, y: y))
                                }
                            }
                            .stroke(Color.gray.opacity(0.3))
                        }
                    )
                ForEach(gameState.buildings) { building in
                    Image(systemName: building.type.icon)
                        .font(.system(size: 30))
                        .foregroundColor(building.level > 1 ? .purple : .primary)
                        .position(building.position)
                        .transition(.opacity)
                        .animation(.easeIn(duration: 0.5), value: gameState.buildings)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.white)
            .cornerRadius(12)
            .shadow(radius: 2)
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onEnded { value in
                        let snappedX = round(value.location.x / 50) * 50
                        let snappedY = round(value.location.y / 50) * 50
                        let position = CGPoint(x: snappedX, y: snappedY)
                        
                        if gameState.isRemoveMode {
                            gameState.removeBuilding(at: position)
                        } else if let type = gameState.selectedBuilding {
                            let building = Building(type: type, position: position)
                            gameState.addBuilding(building)
                        }
                    }
            )
            
            // Citizen Feedback and Tips
            HStack {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(gameState.citizenFeedback, id: \.self) { feedback in
                        Text(feedback)
                            .font(.system(size: 12))
                            .padding(6)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(6)
                    }
                }
                Spacer()
                Button(showTips ? "Hide Tips" : "Show Tips") {
                    withAnimation { showTips.toggle() }
                }
                .padding(8)
                .background(Color.green.opacity(0.2))
                .cornerRadius(8)
            }
            .padding(.horizontal)
            
            if showTips {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(gameState.tips, id: \.self) { tip in
                            Text("📝 \(tip)")
                                .font(.system(size: 12, weight: .medium))
                                .padding(8)
                                .background(tip.contains("High pollution") ? Color.red.opacity(0.2) : Color.yellow.opacity(0.2))
                                .cornerRadius(6)
                        }
                    }
                }
                .frame(height: 80)
                .padding(.horizontal)
            }
            
            // Challenges
            ScrollView(.horizontal) {
                HStack {
                    ForEach(gameState.challenges) { challenge in
                        Text(challenge.isCompleted ? "✅ \(challenge.description)" : "⏳ \(challenge.description)")
                            .font(.system(size: 12))
                            .padding(6)
                            .background(challenge.isCompleted ? Color.green.opacity(0.3) : Color.orange.opacity(0.2))
                            .cornerRadius(6)
                    }
                }
                .padding(.horizontal)
            }
            
            // Mode Toggle, Auto-Build, and Building Selector
            HStack(spacing: 10) {
                Button(gameState.isRemoveMode ? "Switch to Build Mode" : "Switch to Remove Mode") {
                    withAnimation { gameState.isRemoveMode.toggle() }
                }
                .padding(8)
                .background(gameState.isRemoveMode ? Color.red : Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)
                
                Button("Auto-Build City") {
                    withAnimation { gameState.autoBuildCity() }
                }
                .padding(8)
                .background(Color.purple)
                .foregroundColor(.white)
                .cornerRadius(8)
                
                Spacer()
            }
            .padding(.horizontal)
            
            BuildingSelector(gameState: gameState)
        }
        .padding()
        .background(Color(.systemGray6))
    }
}


